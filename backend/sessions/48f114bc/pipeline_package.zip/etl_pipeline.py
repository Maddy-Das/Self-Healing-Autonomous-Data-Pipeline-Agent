import pandas as pd
import sqlite3
from datetime import datetime

# ============================================================
# PRODUCTION ETL PIPELINE — Sales Data Ingestion & Transformation
# ============================================================
# PII Notice: 'email' and 'phone' columns contain PII.
#   - email addresses are masked (preserve domain for analytics)
#   - phone numbers are hashed (irreversible)
#   - In full production, apply field-level encryption at rest
#     and restrict access via RBAC / column-level grants.
# ============================================================

PII_COLUMNS = ['email', 'phone']
ANOMALY_THRESHOLD_QUANTITY = 0       # quantities below this are anomalies
ANOMALY_THRESHOLD_TOTAL_AMOUNT = 0   # total_amounts below this are anomalies
EXPECTED_PRODUCT_VALUES = ['Widget A', 'Widget B', 'Widget C', 'Widget D']
EXPECTED_REGION_VALUES = ['North', 'South', 'East', 'West']
EXPECTED_STATUS_VALUES = ['completed', 'pending', 'cancelled', 'refunded']


def mask_email(email):
    """Mask PII email: a****e@example.com — keeps domain for analytics."""
    if pd.isna(email) or str(email).strip().upper() == 'NULL' or str(email).strip() == '':
        return None
    email = str(email).strip()
    if '@' not in email:
        return None
    local, domain = email.rsplit('@', 1)
    if len(local) <= 2:
        masked_local = local[0] + '****'
    else:
        masked_local = local[0] + '****' + local[-1]
    return f"{masked_local}@{domain}"


def hash_phone(phone):
    """Hash PII phone number for irreversible masking."""
    if pd.isna(phone) or str(phone).strip().upper() == 'NULL' or str(phone).strip() == '':
        return None
    return f"PHONE_{hash(str(phone).strip()) % 1000000:06d}"


def clean_null_strings(df):
    """Replace string 'NULL' / 'null' / empty with actual NaN."""
    for col in df.select_dtypes(include='object').columns:
        df[col] = df[col].replace(
            to_replace=[r'(?i)^\s*NULL\s*$', r'^\s*$'],
            value=None,
            regex=True
        )
    return df


def main():
    print(f"[{datetime.now().isoformat()}] === ETL PIPELINE START ===")

    # ── 1. EXTRACTION ──────────────────────────────────────────
    print("[EXTRACT] Reading CSV from: " + csv_path)
    try:
        df = pd.read_csv(csv_path)
        print(f"[EXTRACT] Raw rows loaded: {len(df):,}")
        print(f"[EXTRACT] Columns: {list(df.columns)}")
    except Exception as e:
        print(f"[FATAL] Failed to read CSV: {e}")
        raise

    # Capture initial row count for validation
    initial_row_count = len(df)

    # ── 2. CLEAN NULL STRINGS ─────────────────────────────────
    df = clean_null_strings(df)
    print(f"[CLEAN] Replaced string 'NULL' values with NaN")

    # ── 3. DEDUPLICATION ──────────────────────────────────────
    pre_dedup = len(df)
    df = df.drop_duplicates()
    removed_dups = pre_dedup - len(df)
    print(f"[DEDUP] Rows before dedup: {pre_dedup:,} | After: {len(df):,} | Removed: {removed_dups:,}")

    # ── 4. TYPE CASTING WITH ERROR HANDLING ───────────────────
    print("[CAST] Enforcing data types...")
    try:
        df['id'] = pd.to_numeric(df['id'], errors='coerce').astype('Int64')
        df['customer_name'] = df['customer_name'].astype(str).replace('nan', None)
        df['quantity'] = pd.to_numeric(df['quantity'], errors='coerce')
        df['unit_price'] = pd.to_numeric(df['unit_price'], errors='coerce')
        df['total_amount'] = pd.to_numeric(df['total_amount'], errors='coerce')
        df['order_date'] = pd.to_datetime(df['order_date'], errors='coerce')
        df['region'] = df['region'].astype(str).replace('nan', None)
        df['status'] = df['status'].astype(str).replace('nan', None)
        # Trim whitespace on string columns
        for col in ['customer_name', 'product', 'region', 'status']:
            if col in df.columns:
                df[col] = df[col].str.strip() if df[col].dtype == 'object' else df[col]
    except Exception as e:
        print(f"[ERROR] Type casting failed: {e}")
        raise
    print(f"[CAST] Types enforced. Rows with null id: {df['id'].isna().sum()}")

    # ── 5. NULL HANDLING STRATEGY ─────────────────────────────
    print("[NULLS] Applying column-level null strategies...")
    # customer_name: fill with 'Unknown' — needed for reporting
    null_name_count = df['customer_name'].isna().sum()
    df['customer_name'] = df['customer_name'].fillna('Unknown')
    print(f"[NULLS] customer_name: filled {null_name_count} nulls → 'Unknown'")

    # email: leave as NULL — PII, will be masked, nulls stay null
    null_email_count = df['email'].isna().sum()
    print(f"[NULLS] email: {null_email_count} nulls preserved (masked downstream)")

    # phone: leave as NULL — PII, will be hashed, nulls stay null
    null_phone_count = df['phone'].isna().sum()
    print(f"[NULLS] phone: {null_phone_count} nulls preserved (hashed downstream)")

    # product: fill with 'Unknown' — required dimension
    null_product_count = df['product'].isna().sum()
    df['product'] = df['product'].fillna('Unknown')
    print(f"[NULLS] product: filled {null_product_count} nulls → 'Unknown'")

    # quantity: fill with 0 and flag — no rows dropped
    null_qty_count = df['quantity'].isna().sum()
    df['quantity'] = df['quantity'].fillna(0)
    print(f"[NULLS] quantity: filled {null_qty_count} nulls → 0 (flagged)")

    # total_amount: fill with 0 and flag — no rows dropped
    null_amt_count = df['total_amount'].isna().sum()
    df['total_amount'] = df['total_amount'].fillna(0)
    print(f"[NULLS] total_amount: filled {null_amt_count} nulls → 0 (flagged)")

    # ── 6. PII MASKING (CRITICAL) ────────────────────────────
    print("[PII] Masking personally identifiable information...")
    df['email_masked'] = df['email'].apply(mask_email)
    df['phone_hashed'] = df['phone'].apply(hash_phone)
    # Drop original PII columns to prevent leakage
    df = df.drop(columns=['email', 'phone'])
    print(f"[PII] email masked → email_masked, phone hashed → phone_hashed")
    print(f"[PII] Original PII columns dropped.")

    # ── 7. ANOMALY FLAGGING ───────────────────────────────────
    print("[ANOMALY] Flagging outlier / invalid values...")
    df['quantity_anomaly'] = (
        (df['quantity'] < ANOMALY_THRESHOLD_QUANTITY) |
        (df['quantity'].isna())
    ).astype(int)
    negative_qty = (df['quantity'] < 0).sum()
    print(f"[ANOMALY] quantity anomalies flagged: {df['quantity_anomaly'].sum()} (negative: {negative_qty})")

    df['total_amount_anomaly'] = (
        (df['total_amount'] < ANOMALY_THRESHOLD_TOTAL_AMOUNT) |
        (df['total_amount'] == 0)
    ).astype(int)
    negative_amt = (df['total_amount'] < 0).sum()
    print(f"[ANOMALY] total_amount anomalies flagged: {df['total_amount_anomaly'].sum()} (negative: {negative_amt})")

    # Flag unknown product
    df['product_anomaly'] = (~df['product'].isin(EXPECTED_PRODUCT_VALUES)).astype(int)
    print(f"[ANOMALY] product anomalies (unexpected values): {df['product_anomaly'].sum()}")

    # ── 8. DERIVED COLUMNS ────────────────────────────────────
    print("[DERIVE] Computing derived columns...")
    df['order_year'] = df['order_date'].dt.year
    df['order_month'] = df['order_date'].dt.month
    df['order_day_of_week'] = df['order_date'].dt.day_name()
    df['computed_total'] = (df['quantity'] * df['unit_price']).round(2)
    df['total_discrepancy'] = (df['total_amount'] - df['computed_total']).abs().round(2)
    df['etl_loaded_at'] = datetime.now().isoformat()
    print(f"[DERIVE] Derived columns added: order_year, order_month, order_day_of_week, computed_total, total_discrepancy")

    # ── 9. DATA VALIDATION ────────────────────────────────────
    print("[VALIDATE] Running data quality checks...")
    final_row_count = len(df)
    assert final_row_count > 0, "FAIL: No rows remain after transformation"
    assert df['id'].notna().all(), "FAIL: Null IDs found in final dataset"
    assert df['id'].is_unique or df['id'].nunique() == final_row_count, "FAIL: Duplicate IDs detected"
    assert df['unit_price'].notna().all(), "FAIL: Null unit_price in final dataset"
    assert df['order_date'].notna().all(), "FAIL: Null order_date in final dataset"
    assert set(df['region'].dropna().unique()).issubset(set(EXPECTED_REGION_VALUES)), "FAIL: Unexpected region values"
    assert set(df['status'].dropna().unique()).issubset(set(EXPECTED_STATUS_VALUES)), "FAIL: Unexpected status values"
    print(f"[VALIDATE] All quality checks PASSED. Final rows: {final_row_count:,}")
    print(f"[VALIDATE] Row count change: {initial_row_count} → {final_row_count}")

    # ── 10. LOAD — IDEMPOTENT UPSERT TO SQLITE ────────────────
    print(f"[LOAD] Writing to SQLite: {db_path}")
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Create table with full schema
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sales_data (
                id INTEGER PRIMARY KEY,
                customer_name TEXT,
                email_masked TEXT,
                phone_hashed TEXT,
                product TEXT,
                quantity REAL,
                unit_price REAL,
                total_amount REAL,
                order_date TEXT,
                region TEXT,
                status TEXT,
                quantity_anomaly INTEGER DEFAULT 0,
                total_amount_anomaly INTEGER DEFAULT 0,
                product_anomaly INTEGER DEFAULT 0,
                order_year INTEGER,
                order_month INTEGER,
                order_day_of_week TEXT,
                computed_total REAL,
                total_discrepancy REAL,
                etl_loaded_at TEXT
            )
        """)

        # Create indexes for common query patterns
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_region ON sales_data(region)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_status ON sales_data(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_order_date ON sales_data(order_date)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_product ON sales_data(product)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sales_loaded_at ON sales_data(etl_loaded_at)")
        conn.commit()

        # Idempotent upsert using INSERT OR REPLACE
        # Prepare dataframe columns in table order
        table_columns = [
            'id', 'customer_name', 'email_masked', 'phone_hashed', 'product',
            'quantity', 'unit_price', 'total_amount', 'order_date', 'region', 'status',
            'quantity_anomaly', 'total_amount_anomaly', 'product_anomaly',
            'order_year', 'order_month', 'order_day_of_week',
            'computed_total', 'total_discrepancy', 'etl_loaded_at'
        ]
        df_load = df[table_columns].copy()
        df_load['order_date'] = df_load['order_date'].astype(str)

        placeholders = ', '.join(['?'] * len(table_columns))
        col_list = ', '.join(table_columns)
        upsert_sql = f"INSERT OR REPLACE INTO sales_data ({col_list}) VALUES ({placeholders})"

        rows_written = 0
        for _, row in df_load.iterrows():
            cursor.execute(upsert_sql, tuple(row))
            rows_written += 1

        conn.commit()
        print(f"[LOAD] Upserted {rows_written:,} rows (INSERT OR REPLACE — idempotent)")

        # Verify load
        result = cursor.execute("SELECT COUNT(*) FROM sales_data").fetchone()
        db_count = result[0]
        assert db_count == final_row_count, f"FAIL: Row count mismatch — expected {final_row_count}, got {db_count}"
        print(f"[LOAD] Verification: {db_count:,} rows confirmed in database")

        conn.close()
    except Exception as e:
        print(f"[FATAL] Load failed: {e}")
        raise

    print(f"[{datetime.now().isoformat()}] === ETL PIPELINE COMPLETE ===")


main()