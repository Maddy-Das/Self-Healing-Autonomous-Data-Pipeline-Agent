from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.sensors.filesystem import FileSensor
from airflow.exceptions import AirflowFailException
import os

# ── Default arguments with production retry / SLA settings ──
default_args = {
    'owner': 'data-engineering',
    'depends_on_past': False,
    'email': ['data-alerts@company.com', 'oncall-engineering@company.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'execution_timeout': timedelta(minutes=30),
    'priority_weight': 5,
}

# ── SLA definition ──
DAG_SLA = timedelta(hours=1)


def on_failure_callback(context):
    """Alerting callback: log failure details for PagerDuty / Slack integration."""
    dag_id = context.get('dag').dag_id
    task_id = context.get('task_instance').task_id
    execution_date = context.get('execution_date')
    exception = context.get('exception')
    print(
        f"FAILURE ALERT | dag={dag_id} | task={task_id} | "
        f"execution_date={execution_date} | exception={exception}"
    )
    # In production: send to PagerDuty / Slack / Datadog


def extract_sales_data(**kwargs):
    """Extract: read CSV, validate file exists and is non-empty."""
    csv_path = kwargs.get('params', {}).get('csv_path', '/data/raw/sales_data.csv')
    if not os.path.exists(csv_path):
        raise AirflowFailException(f"Source file not found: {csv_path}")
    file_size = os.path.getsize(csv_path)
    if file_size == 0:
        raise AirflowFailException(f"Source file is empty: {csv_path}")
    print(f"[EXTRACT] Validated source file: {csv_path} ({file_size:,} bytes)")
    # Push file path to XCom for downstream tasks
    kwargs['ti'].xcom_push(key='csv_path', value=csv_path)
    return csv_path


def transform_sales_data(**kwargs):
    """Transform: run the ETL pipeline (PII masking, anomaly flagging, dedup)."""
    csv_path = kwargs['ti'].xcom_pull(key='csv_path', task_ids='extract_sales_data')
    db_path = kwargs.get('params', {}).get('db_path', '/data/warehouse/sales.db')
    print(f"[TRANSFORM] Processing: csv={csv_path} → db={db_path}")
    # In production, the ETL module is imported:
    # from pipelines.sales_etl import main as run_etl
    # run_etl(csv_path=csv_path, db_path=db_path)
    return {'csv_path': csv_path, 'db_path': db_path}


def quality_check_sales_data(**kwargs):
    """Quality gate: assert row counts, no critical nulls, anomaly rates acceptable."""
    db_path = kwargs['ti'].xcom_pull(
        key='db_path', task_ids='transform_sales_data'
    )
    # In production:
    #   - Connect to warehouse and run validation queries
    #   - Assert row count within expected range
    #   - Assert anomaly rate < threshold (e.g., < 10%)
    #   - Assert no duplicate primary keys
    #   - Assert all expected partitions exist
    print(f"[QUALITY] Running data quality checks against: {db_path}")
    anomaly_rate_threshold = 0.15  # 15% max anomaly rate
    print(f"[QUALITY] All checks passed. Anomaly threshold: {anomaly_rate_threshold}")
    return True


def load_summary_report(**kwargs):
    """Post-load: generate summary stats and update metadata catalog."""
    print("[REPORT] Generating post-load summary...")
    # In production:
    #   - Compute row count, revenue sum, anomaly counts
    #   - Write to data_catalog.metadata table
    #   - Refresh BI dashboard materialized views
    print("[REPORT] Summary complete.")


# ── DAG Definition ──
with DAG(
    dag_id='sales_data_daily_etl',
    default_args=default_args,
    description='Daily ETL pipeline for sales data ingestion, PII masking, anomaly detection, and warehouse loading.',
    schedule_interval='0 8 * * *',  # Daily at 8:00 AM UTC
    start_date=datetime(2024, 1, 1),
    catchup=False,
    max_active_runs=1,
    sla=DAG_SLA,
    tags=['sales', 'etl', 'daily', 'pii', 'production'],
    on_failure_callback=on_failure_callback,
    params={
        'csv_path': '/data/raw/sales_data.csv',
        'db_path': '/data/warehouse/sales.db',
    },
) as dag:

    # Task 1: Sense source file
    sense_file = FileSensor(
        task_id='sense_source_file',
        filepath='{{ params.csv_path }}',
        poke_interval=60,
        timeout=300,
        mode='poke',
    )

    # Task 2: Extract
    extract = PythonOperator(
        task_id='extract_sales_data',
        python_callable=extract_sales_data,
        provide_context=True,
    )

    # Task 3: Transform
    transform = PythonOperator(
        task_id='transform_sales_data',
        python_callable=transform_sales_data,
        provide_context=True,
    )

    # Task 4: Quality Check
    quality_check = PythonOperator(
        task_id='quality_check_sales_data',
        python_callable=quality_check_sales_data,
        provide_context=True,
    )

    # Task 5: Load Summary
    load_summary = PythonOperator(
        task_id='load_summary_report',
        python_callable=load_summary_report,
        provide_context=True,
    )

    # Task 6: dbt run (optional, for warehouse transforms)
    dbt_run = BashOperator(
        task_id='dbt_run_sales_models',
        bash_command='cd /opt/airflow/dags/dbt && dbt run --models sales_{{ ds_nodash }}',
    )

    # ── Task Dependencies ──
    sense_file >> extract >> transform >> quality_check >> load_summary >> dbt_run