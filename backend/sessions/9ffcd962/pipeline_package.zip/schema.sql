-- Target table for transformed sales orders (PII pseudonymized)
CREATE TABLE IF NOT EXISTS sales_orders (
    id INTEGER PRIMARY KEY,
    customer_name_hash TEXT NOT NULL,
    email_hash TEXT,
    phone_masked TEXT,
    product TEXT NOT NULL,
    quantity REAL NOT NULL DEFAULT 0,
    unit_price REAL NOT NULL DEFAULT 0,
    total_amount REAL NOT NULL DEFAULT 0,
    order_date TEXT,
    region TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unknown',
    quantity_is_imputed INTEGER DEFAULT 0,
    is_anomaly INTEGER DEFAULT 0,
    loaded_at TEXT NOT NULL,
    UNIQUE(id)
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_sales_orders_order_date ON sales_orders(order_date);
CREATE INDEX IF NOT EXISTS idx_sales_orders_region ON sales_orders(region);
CREATE INDEX IF NOT EXISTS idx_sales_orders_status ON sales_orders(status);
CREATE INDEX IF NOT EXISTS idx_sales_orders_product ON sales_orders(product);
CREATE INDEX IF NOT EXISTS idx_sales_orders_anomaly ON sales_orders(is_anomaly);

-- Data quality audit log table
CREATE TABLE IF NOT EXISTS data_quality_audit (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_timestamp TEXT NOT NULL,
    total_rows INTEGER NOT NULL,
    anomaly_count INTEGER DEFAULT 0,
    null_counts TEXT,
    pipeline_status TEXT DEFAULT 'success',
    error_message TEXT
);

-- Anomaly detail table for investigation
CREATE TABLE IF NOT EXISTS anomaly_details (
    anomaly_id INTEGER PRIMARY KEY AUTOINCREMENT,
    record_id INTEGER NOT NULL,
    field_name TEXT NOT NULL,
    issue_description TEXT NOT NULL,
    detected_at TEXT NOT NULL,
    FOREIGN KEY (record_id) REFERENCES sales_orders(id)
);

CREATE INDEX IF NOT EXISTS idx_anomaly_details_record ON anomaly_details(record_id);
