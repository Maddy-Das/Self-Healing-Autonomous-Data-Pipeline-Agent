import pandas as pd
import sqlite3
import hashlib
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configurable thresholds
NEGATIVE_VALUE_THRESHOLD = 0
TOTAL_AMOUNT_TOLERANCE = 0.50
EXPECTED_COLUMNS = ['id', 'customer_name', 'email', 'phone', 'product', 'quantity',
                    'unit_price', 'total_amount', 'order_date', 'region', 'status']

def extract(csv_path: str) -> pd.DataFrame:
    """Extract data from CSV source."""
    logger.info(f"Extracting data from {csv_path}")
    try:
        df = pd.read_csv(csv_path)
        logger.info(f"Extracted {len(df)} rows with columns: {list(df.columns)}")
    except FileNotFoundError:
        logger.error(f"Source file not found: {csv_path}")
        raise
    except Exception as e:
        logger.error(f"Error reading CSV: {e}")
        raise

    # Replace string 'NULL' / 'null' / empty strings with actual NaN
    df = df.replace(['NULL', 'null', 'None', ''], pd.NA)
    logger.info(f"Replaced string NULL literals with NaN")

    # Validate expected columns exist
    missing_cols = set(EXPECTED_COLUMNS) - set(df.columns)
    if missing_cols:
        raise ValueError(f"Missing expected columns: {missing_cols}")

    return df


def transform(df: pd.DataFrame) -> pd.DataFrame:
    """Apply transformations: clean, validate, pseudonymize PII, derive fields."""
    logger.info(f"Transforming {len(df)} rows")
    initial_count = len(df)
    anomalies = []

    # --- Handle nulls in critical columns ---
    null_counts = df.isnull().sum()
    for col, count in null_counts.items():
        if count > 0:
            logger.warning(f"Column '{col}' has {count} null values ({count/len(df)*100:.1f}%)")

    # Fill missing product with 'Unknown'
    df['product'] = df['product'].fillna('Unknown')

    # Fill missing quantity with 0 and flag
    df['quantity_is_imputed'] = df['quantity'].isnull()
    df['quantity'] = df['quantity'].fillna(0)

    # Fill missing unit_price with median (shouldn't be null per profile, but safe)
    if df['unit_price'].isnull().any():
        median_price = df['unit_price'].median()
        df['unit_price'] = df['unit_price'].fillna(median_price)
        logger.warning(f"Filled missing unit_price with median: {median_price}")

    # --- Handle negative values ---
    neg_quantity_mask = df['quantity'] < NEGATIVE_VALUE_THRESHOLD
    if neg_quantity_mask.any():
        neg_ids = df.loc[neg_quantity_mask, 'id'].tolist()
        anomalies.extend([{'id': rid, 'field': 'quantity', 'issue': f'negative value: {val}'}
                          for rid, val in df.loc[neg_quantity_mask, ['id', 'quantity']].values])
        logger.warning(f"Found {neg_quantity_mask.sum()} negative quantity values for ids: {neg_ids}")
        df.loc[neg_quantity_mask, 'quantity'] = 0
        df.loc[neg_quantity_mask, 'quantity_is_imputed'] = True

    neg_amount_mask = df['total_amount'] < NEGATIVE_VALUE_THRESHOLD
    if neg_amount_mask.any():
        neg_ids = df.loc[neg_amount_mask, 'id'].tolist()
        anomalies.extend([{'id': rid, 'field': 'total_amount', 'issue': f'negative value: {val}'}
                          for rid, val in df.loc[neg_amount_mask, ['id', 'total_amount']].values])
        logger.warning(f"Found {neg_amount_mask.sum()} negative total_amount values for ids: {neg_ids}")
        df.loc[neg_amount_mask, 'total_amount'] = 0

    # --- Recalculate total_amount and flag discrepancies ---
    df['calculated_total'] = df['quantity'] * df['unit_price']
    df['total_amount'] = df['total_amount'].fillna(df['calculated_total'])

    discrepancy_mask = (df['total_amount'] - df['calculated_total']).abs() > TOTAL_AMOUNT_TOLERANCE
    if discrepancy_mask.any():
        disc_ids = df.loc[discrepancy_mask, 'id'].tolist()
        anomalies.extend([{'id': rid, 'field': 'total_amount',
                           'issue': f'discrepancy: stored={stored:.2f}, calculated={calc:.2f}'}
                          for rid, stored, calc in
                          df.loc[discrepancy_mask, ['id', 'total_amount', 'calculated_total']].values])
        logger.warning(f"Total amount discrepancies for ids: {disc_ids}")
        df['total_amount'] = df['calculated_total']

    df = df.drop(columns=['calculated_total'])

    # --- PII Pseudonymization ---
    # Hash email with SHA-256
    df['email_hash'] = df['email'].apply(
        lambda x: hashlib.sha256(str(x).encode('utf-8')).hexdigest() if pd.notna(x) else None
    )

    # Mask phone: show only last 4 digits
    df['phone_masked'] = df['phone'].apply(
        lambda x: '****-****-' + str(x).replace('-', '').replace('+', '').replace(' ', '')[-4:]
        if pd.notna(x) and len(str(x).replace('-', '').replace('+', '').replace(' ', '')) >= 4
        else None
    )

    # Hash customer name (pseudonymization)
    df['customer_name_hash'] = df['customer_name'].apply(
        lambda x: hashlib.sha256(str(x).encode('utf-8')).hexdigest() if pd.notna(x) else None
    )

    # Remove original PII columns
    df = df.drop(columns=['email', 'phone', 'customer_name'])
    logger.info("PII columns pseudonymized: email->email_hash, phone->phone_masked, customer_name->customer_name_hash")

    # --- Parse dates ---
    df['order_date'] = pd.to_datetime(df['order_date'], errors='coerce')
    if df['order_date'].isnull().any():
        logger.warning(f"{df['order_date'].isnull().sum()} rows with invalid order_date")

    # --- Data quality flags ---
    df['is_anomaly'] = df['id'].isin([a['id'] for a in anomalies])
    df['loaded_at'] = datetime.utcnow().isoformat()

    # Row count validation
    final_count = len(df)
    if final_count != initial_count:
        logger.error(f"Row count mismatch: started with {initial_count}, ended with {final_count}")
        raise ValueError("Row count changed during transformation — possible data loss")

    logger.info(f"Transformation complete: {final_count} rows, {len(anomalies)} anomalies flagged")
    return df, anomalies


def load(df: pd.DataFrame, db_path: str) -> int:
    """Load transformed data to SQLite with UPSERT (idempotent)."""
    logger.info(f"Loading {len(df)} rows to {db_path}")

    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()

        # Create table if not exists
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sales_orders (
                id INTEGER PRIMARY KEY,
                customer_name_hash TEXT,
                email_hash TEXT,
                phone_masked TEXT,
                product TEXT,
                quantity REAL,
                unit_price REAL,
                total_amount REAL,
                order_date TEXT,
                region TEXT,
                status TEXT,
                quantity_is_imputed INTEGER DEFAULT 0,
                is_anomaly INTEGER DEFAULT 0,
                loaded_at TEXT,
                UNIQUE(id)
            )
        ''')

        # Create indexes for common query patterns
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_order_date ON sales_orders(order_date)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_region ON sales_orders(region)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_status ON sales_orders(status)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_product ON sales_orders(product)')

        # Create data quality audit table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS data_quality_audit (
                audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_timestamp TEXT,
                total_rows INTEGER,
                anomaly_count INTEGER,
                null_counts TEXT
            )
        ''')

        # UPSERT using INSERT OR REPLACE for idempotency
        rows_loaded = 0
        for _, row in df.iterrows():
            cursor.execute('''
                INSERT OR REPLACE INTO sales_orders
                    (id, customer_name_hash, email_hash, phone_masked, product,
                     quantity, unit_price, total_amount, order_date, region, status,
                     quantity_is_imputed, is_anomaly, loaded_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                int(row['id']),
                row.get('customer_name_hash'),
                row.get('email_hash'),
                row.get('phone_masked'),
                row.get('product'),
                float(row['quantity']) if pd.notna(row['quantity']) else 0.0,
                float(row['unit_price']) if pd.notna(row['unit_price']) else 0.0,
                float(row['total_amount']) if pd.notna(row['total_amount']) else 0.0,
                str(row['order_date']) if pd.notna(row['order_date']) else None,
                row.get('region'),
                row.get('status'),
                1 if row.get('quantity_is_imputed', False) else 0,
                1 if row.get('is_anomaly', False) else 0,
                row.get('loaded_at')
            ))
            rows_loaded += 1

        # Log audit record
        null_summary = df.isnull().sum().to_dict()
        cursor.execute('''
            INSERT INTO data_quality_audit (run_timestamp, total_rows, anomaly_count, null_counts)
            VALUES (?, ?, ?, ?)
        ''', (
            datetime.utcnow().isoformat(),
            rows_loaded,
            int(df['is_anomaly'].sum()),
            str(null_summary)
        ))

        conn.commit()
        logger.info(f"Successfully loaded {rows_loaded} rows (UPSERT)")

        # Verify row count
        cursor.execute('SELECT COUNT(*) FROM sales_orders')
        db_count = cursor.fetchone()[0]
        if db_count != rows_loaded:
            logger.error(f"Verification failed: expected {rows_loaded}, found {db_count}")
            raise ValueError("Row count verification failed")

        return rows_loaded

    except Exception as e:
        conn.rollback()
        logger.error(f"Load failed, transaction rolled back: {e}")
        raise
    finally:
        conn.close()


def run_pipeline(csv_path: str, db_path: str) -> dict:
    """Main pipeline orchestrator with error handling."""
    start_time = datetime.utcnow()
    result = {
        'status': 'success',
        'input_rows': 0,
        'output_rows': 0,
        'anomalies': [],
        'duration_seconds': 0,
        'errors': []
    }

    try:
        # Extract
        df = extract(csv_path)
        result['input_rows'] = len(df)

        # Transform
        df_transformed, anomalies = transform(df)
        result['anomalies'] = anomalies

        # Load
        rows_loaded = load(df_transformed, db_path)
        result['output_rows'] = rows_loaded

    except Exception as e:
        result['status'] = 'failed'
        result['errors'].append(str(e))
        logger.error(f"Pipeline failed: {e}")
        raise

    finally:
        result['duration_seconds'] = (datetime.utcnow() - start_time).total_seconds()
        logger.info(f"Pipeline {result['status']}: {result['input_rows']} -> {result['output_rows']} rows "
                    f"in {result['duration_seconds']:.2f}s")

    return result


# Execute pipeline
if __name__ == "__main__" or 'csv_path' in dir():
    try:
        result = run_pipeline(csv_path, db_path)
    except NameError:
        pass
