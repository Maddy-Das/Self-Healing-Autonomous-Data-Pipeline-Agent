-- ============================================================
-- PostgreSQL DDL: sales_data (production schema)
-- Partitioned by order_year for query performance on date ranges
-- ============================================================

-- Enum types for controlled vocabularies
CREATE TYPE region_enum AS ENUM ('North', 'South', 'East', 'West');
CREATE TYPE order_status_enum AS ENUM ('completed', 'pending', 'cancelled', 'refunded');

-- Partitioned parent table
CREATE TABLE sales_data (
    id              BIGINT          NOT NULL,
    customer_name   VARCHAR(255)    NOT NULL DEFAULT 'Unknown',
    email_masked    VARCHAR(255),
    phone_hashed    VARCHAR(50),
    product         VARCHAR(100)    NOT NULL DEFAULT 'Unknown',
    quantity        NUMERIC(12,2)   NOT NULL DEFAULT 0,
    unit_price      NUMERIC(12,2)   NOT NULL,
    total_amount    NUMERIC(14,2)   NOT NULL DEFAULT 0,
    order_date      DATE            NOT NULL,
    region          region_enum     NOT NULL,
    status          order_status_enum NOT NULL DEFAULT 'pending',
    quantity_anomaly     SMALLINT   NOT NULL DEFAULT 0,
    total_amount_anomaly SMALLINT   NOT NULL DEFAULT 0,
    product_anomaly      SMALLINT   NOT NULL DEFAULT 0,
    computed_total       NUMERIC(14,2),
    total_discrepancy    NUMERIC(14,2),
    order_year      INT             NOT NULL,
    order_month     INT             NOT NULL,
    order_day_of_week VARCHAR(15)   NOT NULL,
    etl_loaded_at   TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    -- Primary key includes partition key
    PRIMARY KEY (id, order_year),

    -- Check constraints for data integrity
    CONSTRAINT ck_unit_price_positive CHECK (unit_price >= 0),
    CONSTRAINT ck_quantity_anomaly_flag CHECK (quantity_anomaly IN (0, 1)),
    CONSTRAINT ck_total_amount_anomaly_flag CHECK (total_amount_anomaly IN (0, 1)),
    CONSTRAINT ck_product_anomaly_flag CHECK (product_anomaly IN (0, 1))
) PARTITION BY LIST (order_year);

-- Table and column comments
COMMENT ON TABLE sales_data IS 'Partitioned sales order fact table with PII masking and anomaly flags. Ingested daily via Airflow ETL pipeline.';
COMMENT ON COLUMN sales_data.id IS 'Unique order identifier from source system';
COMMENT ON COLUMN sales_data.customer_name IS 'Customer display name (non-PII). Nulls filled with Unknown.';
COMMENT ON COLUMN sales_data.email_masked IS 'PII-masked email preserving domain for analytics. Original email is not stored.';
COMMENT ON COLUMN sales_data.phone_hashed IS 'Irreversibly hashed phone number. Original phone is not stored.';
COMMENT ON COLUMN sales_data.quantity_anomaly IS '1 = quantity is negative or was originally null; 0 = normal';
COMMENT ON COLUMN sales_data.total_amount_anomaly IS '1 = total_amount is negative, zero, or was originally null; 0 = normal';
COMMENT ON COLUMN sales_data.product_anomaly IS '1 = product value not in expected set; 0 = normal';
COMMENT ON COLUMN sales_data.total_discrepancy IS 'Absolute difference between source total_amount and computed quantity*unit_price';
COMMENT ON COLUMN sales_data.etl_loaded_at IS 'Timestamp when ETL pipeline loaded this row';

-- Partitions (add new year partitions as needed)
CREATE TABLE sales_data_2024 PARTITION OF sales_data FOR VALUES IN (2024);
CREATE TABLE sales_data_2025 PARTITION OF sales_data FOR VALUES IN (2025);
CREATE TABLE sales_data_default PARTITION OF sales_data DEFAULT;

-- Performance indexes
CREATE INDEX idx_sales_region ON sales_data (region);
CREATE INDEX idx_sales_status ON sales_data (status);
CREATE INDEX idx_sales_product ON sales_data (product);
CREATE INDEX idx_sales_order_date ON sales_data (order_date);
CREATE INDEX idx_sales_loaded_at ON sales_data (etl_loaded_at);
CREATE INDEX idx_sales_status_region ON sales_data (status, region);
CREATE INDEX idx_sales_quantity_anomaly ON sales_data (quantity_anomaly) WHERE quantity_anomaly = 1;
CREATE INDEX idx_sales_total_anomaly ON sales_data (total_amount_anomaly) WHERE total_amount_anomaly = 1;

-- Trigger for updated_at auto-maintenance
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_sales_data_updated_at
    BEFORE UPDATE ON sales_data
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();